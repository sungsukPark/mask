﻿using System;

using System.Collections.Generic;
using System.Text;
using System.IO.Ports; 
using System.Security.Cryptography;

namespace SmartSerialPort_NewEX
{
    class clsSerialComm
    {
        private System.IO.Ports.SerialPort _serialP1;
        private int _mType = 0;
        
        //STX, ETX
        private byte[] byteSTX = {0x3A};                //3A                   
        private byte[] byteETX = {0x0D};                //0D  

        //Machine Type
        private byte[] byteMType1 = {0x30, 0x31};   //1공정 01
        private byte[] byteMType2 = {0x30, 0x32};   //2공정 02

        // 
        private byte[] byteDirect1 = {0x30,0x30,0x30,0x30,0x33,0x30,0x30,0x30};   //정(시계)방향    00003000
        private byte[] byteDirect2 = {0x31,0x30,0x30,0x30,0x33,0x30,0x30,0x30};   //역(반시계)방향  10003000

        //SEND Command 
        private byte[] byteSND_MMR =  { 0x30, 0x31 };    //Main Motor Run - 1
        private byte[] byteSND_MMT =  { 0x30, 0x30 };    //Main Motor Stop - 2
        
        private byte[] byteSND_SM1R = { 0x30, 0x33 };    //Sub Motor1 Run - 3
        private byte[] byteSND_SM1T = { 0x30, 0x32 };    //Sub Motor1 Stop - 4
        
        private byte[] byteSND_SM2R = { 0x30, 0x35 };    //Sub Motor2 Run - 5
        private byte[] byteSND_SM2T = { 0x30, 0x34 };    //Sub Motor2 Stop - 6
         
        private byte[] byteSND_EMGSTP = { 0x31, 0x30 };    //Emergency Stop - 7

        private byte[] byteSND_MACSTE = { 0x30, 0x46 };    //Get Machine Status - 8

        private byte[] byteSND_ALMRST = { 0x30, 0x35 };    //Alarm Reset - 9 

        private byte[] byteSND_PREACT = { 0x30, 0x37 };    //공압기기동작 - 10

        private byte[] byteSND_SSNACT = { 0x30, 0x38 };    //초음파 동작 - 11

        //RECV Command 
        private byte[] byteRCV_MMR = { 0x38, 0x31 };    //Main Motor Run - 1
        private byte[] byteRCV_MMT = { 0x38, 0x30 };    //Main Motor Stop - 2

        private byte[] byteRCV_SM1R = { 0x38, 0x33 };    //Sub Motor1 Run - 3
        private byte[] byteRCV_SM1T = { 0x38, 0x32 };    //Sub Motor1 Stop - 4

        private byte[] byteRCV_SM2R = { 0x38, 0x35 };    //Sub Motor2 Run - 5
        private byte[] byteRCV_SM2T = { 0x38, 0x34 };    //Sub Motor2 Stop - 6

        private byte[] byteRCV_EMGSTP = { 0x31, 0x30 };    //Emergency Stop - 7

        private byte[] byteRCV_MACSTE = { 0x30, 0x46 };    //Get Machine Status - 8

        private byte[] byteRCV_ALMRST = { 0x30, 0x35 };    //Alarm Reset - 9 

        private byte[] byteRCV_PREACT = { 0x30, 0x37 };    //공압기기동작 - 10

        private byte[] byteRCV_SSNACT = { 0x30, 0x38 };    //초음파 동작 - 11

        public clsSerialComm(SerialPort p1, int mType)
        {
            _serialP1 = p1;
            _mType = mType; //공정1, 공정2
            //_serialP1.Open(); 
        }

        private byte[] m_bSendData;             //송신할 데이터를 저장할 바이트 배열

        //Main Motor Run
        public void MainMotorRun(){
            m_bSendData = new Byte[] { 0x30, 0x31, 0x30, 0x31, 0x30, 0x38, 0x30, 0x30, 0x30, 0x30, 0x33, 0x30, 0x30, 0x30, 0x30, 0x42, 0x0D };
            //_serialP1.Write(m_bSendData, 0, m_bSendData.Length);

            byte[] chkSum2 = CheckSum(new Byte[] { 0x30, 0x31, 0x30, 0x31, 0x30, 0x38, 0x30, 0x30, 0x30, 0x30, 0x33, 0x30, 0x30, 0x30 }, 14);
            
            System.Threading.Thread.Sleep(200);
            
        }

        //Main Motor Stop
        public void MainMotorStop()
        {
            
        }

        //Sub motor1 Run    
        public void SubMotor1Run()
        {

        }

        //Sub Motor1 Stop
        public void SubMotor1Stop()
        {

        }

        //Sub Motor2 Run
        public void SubMotor2Run()
        {

        }

        //Sub Motor2 Stop
        public void SubMotor2Stop()
        {

        }

        //Emergency Stop
        public void EmergencyStop()
        { 
        
        }

        //Get Machine State
        public void GetMachineState() { 
        
        }

        public void AlarmReset() { 
        
        }

        //공압 기기 동작
        public void ActCompressStart() { 
        
        }

        //초음파 동작
        public void SuperWaveStart() { 
        
        }

        private byte[] checkSum(byte[] buffer)
        {
            int sum = 0;
            foreach (var b in buffer)
                sum += b;
            sum %= 0x100;
            byte[] byteCheckSum = new byte[2];
            byteCheckSum[0] = (byte)((sum >> 4) + 0x30);
            byteCheckSum[1] = (byte)((sum & 0xF) + 0x30);
            return byteCheckSum;
        }

        public byte[] GetByteChecksum(byte[] bytes)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

            byte[] hashValue = md5.ComputeHash(bytes);

            return hashValue;
        }

        //CheckSum을 계산한다.
        private byte[] CheckSum(byte[] _PacketData, int PacketLength)
        {
            byte _CheckSumByte = 0x00;
            for (int i = 0; i < PacketLength; i++)
                _CheckSumByte ^= _PacketData[i];
            int hex = Int32.Parse(_CheckSumByte.ToString());
            string checkSum = hex.ToString("X2");
            return str2bytes(checkSum);
        }

        static public byte[] str2bytes(string byteData)
        {
            System.Text.ASCIIEncoding asencoding = new System.Text.ASCIIEncoding();
            return Encoding.Default.GetBytes(byteData);
        }

    }
}
