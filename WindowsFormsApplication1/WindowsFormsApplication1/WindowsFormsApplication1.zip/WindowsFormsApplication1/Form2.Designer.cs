﻿namespace SmartSerialPort_NewEX
{
    partial class Form2
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mainMenu1 = new System.Windows.Forms.MainMenu(this.components);
            this.pnlLogin = new System.Windows.Forms.Panel();
            this.button30 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnLogin = new System.Windows.Forms.Button();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlProcess = new System.Windows.Forms.Panel();
            this.btnCommTest = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.rdoFlow1 = new System.Windows.Forms.RadioButton();
            this.btnTestProcess = new System.Windows.Forms.Button();
            this.rdoFlow2 = new System.Windows.Forms.RadioButton();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnErrReset = new System.Windows.Forms.Button();
            this.btnErrManualDown = new System.Windows.Forms.Button();
            this.btnReScan = new System.Windows.Forms.Button();
            this.btnInitDevice = new System.Windows.Forms.Button();
            this.lblCurrTime = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.lblCntPerMin = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.lblEaPerDay = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.lblErrCntPerDay = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnUserChg = new System.Windows.Forms.Button();
            this.lblCongrat = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCntPerMin = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCntChg = new System.Windows.Forms.Button();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.ChkState1_1 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.tmrCurrTime = new System.Windows.Forms.Timer(this.components);
            this.serialP1 = new System.IO.Ports.SerialPort(this.components);
            this.ChkState1_3 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState1_8 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState1_2 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState1_7 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState1_6 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState1_4 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState1_5 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.picLogo1 = new System.Windows.Forms.PictureBox();
            this.picMachineType = new System.Windows.Forms.PictureBox();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.ChkState2_1 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState2_2 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState2_3 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState2_4 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState2_5 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState2_6 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.ChkState2_7 = new Microsoft.VisualBasic.PowerPacks.OvalShape();
            this.pnlLogin.SuspendLayout();
            this.pnlProcess.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMachineType)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlLogin
            // 
            this.pnlLogin.BackColor = System.Drawing.Color.White;
            this.pnlLogin.Controls.Add(this.button30);
            this.pnlLogin.Controls.Add(this.button21);
            this.pnlLogin.Controls.Add(this.button22);
            this.pnlLogin.Controls.Add(this.button23);
            this.pnlLogin.Controls.Add(this.button24);
            this.pnlLogin.Controls.Add(this.button25);
            this.pnlLogin.Controls.Add(this.button26);
            this.pnlLogin.Controls.Add(this.button27);
            this.pnlLogin.Controls.Add(this.button28);
            this.pnlLogin.Controls.Add(this.button29);
            this.pnlLogin.Controls.Add(this.button12);
            this.pnlLogin.Controls.Add(this.button13);
            this.pnlLogin.Controls.Add(this.button14);
            this.pnlLogin.Controls.Add(this.button15);
            this.pnlLogin.Controls.Add(this.button16);
            this.pnlLogin.Controls.Add(this.button17);
            this.pnlLogin.Controls.Add(this.button18);
            this.pnlLogin.Controls.Add(this.button19);
            this.pnlLogin.Controls.Add(this.button20);
            this.pnlLogin.Controls.Add(this.button11);
            this.pnlLogin.Controls.Add(this.button10);
            this.pnlLogin.Controls.Add(this.button9);
            this.pnlLogin.Controls.Add(this.button8);
            this.pnlLogin.Controls.Add(this.button7);
            this.pnlLogin.Controls.Add(this.button6);
            this.pnlLogin.Controls.Add(this.button5);
            this.pnlLogin.Controls.Add(this.button4);
            this.pnlLogin.Controls.Add(this.button3);
            this.pnlLogin.Controls.Add(this.button2);
            this.pnlLogin.Controls.Add(this.btnLogin);
            this.pnlLogin.Controls.Add(this.txtUserName);
            this.pnlLogin.Controls.Add(this.label1);
            this.pnlLogin.Controls.Add(this.picLogo);
            this.pnlLogin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLogin.Location = new System.Drawing.Point(0, 0);
            this.pnlLogin.Name = "pnlLogin";
            this.pnlLogin.Size = new System.Drawing.Size(798, 455);
            this.pnlLogin.TabIndex = 1;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.White;
            this.button30.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button30.Location = new System.Drawing.Point(710, 268);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(77, 179);
            this.button30.TabIndex = 36;
            this.button30.Text = "Enter";
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.White;
            this.button21.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button21.Location = new System.Drawing.Point(247, 388);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(69, 59);
            this.button21.TabIndex = 35;
            this.button21.Text = "ㅊ";
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.White;
            this.button22.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button22.Location = new System.Drawing.Point(317, 388);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(69, 59);
            this.button22.TabIndex = 34;
            this.button22.Text = "ㅍ";
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.White;
            this.button23.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button23.Location = new System.Drawing.Point(457, 388);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(69, 59);
            this.button23.TabIndex = 33;
            this.button23.Text = "ㅜ";
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.White;
            this.button24.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button24.Location = new System.Drawing.Point(597, 388);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(112, 59);
            this.button24.TabIndex = 32;
            this.button24.Text = "한/영";
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.White;
            this.button25.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button25.Location = new System.Drawing.Point(527, 388);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(69, 59);
            this.button25.TabIndex = 31;
            this.button25.Text = "ㅡ";
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.White;
            this.button26.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button26.Location = new System.Drawing.Point(177, 388);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(69, 59);
            this.button26.TabIndex = 30;
            this.button26.Text = "ㅌ";
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.White;
            this.button27.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button27.Location = new System.Drawing.Point(387, 388);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(69, 59);
            this.button27.TabIndex = 29;
            this.button27.Text = "ㅠ";
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.White;
            this.button28.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button28.Location = new System.Drawing.Point(107, 388);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(69, 59);
            this.button28.TabIndex = 28;
            this.button28.Text = "ㅋ";
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.White;
            this.button29.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button29.Location = new System.Drawing.Point(9, 388);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(98, 59);
            this.button29.TabIndex = 27;
            this.button29.Text = "Shift";
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.White;
            this.button12.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button12.Location = new System.Drawing.Point(247, 328);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(69, 59);
            this.button12.TabIndex = 26;
            this.button12.Text = "ㄹ";
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button13.Location = new System.Drawing.Point(317, 328);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(69, 59);
            this.button13.TabIndex = 25;
            this.button13.Text = "ㅎ";
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.White;
            this.button14.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button14.Location = new System.Drawing.Point(457, 328);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(69, 59);
            this.button14.TabIndex = 24;
            this.button14.Text = "ㅓ";
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.White;
            this.button15.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button15.Location = new System.Drawing.Point(597, 328);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(69, 59);
            this.button15.TabIndex = 23;
            this.button15.Text = "ㅣ";
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.White;
            this.button16.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button16.Location = new System.Drawing.Point(527, 328);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(69, 59);
            this.button16.TabIndex = 22;
            this.button16.Text = "ㅏ";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.White;
            this.button17.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button17.Location = new System.Drawing.Point(177, 328);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(69, 59);
            this.button17.TabIndex = 21;
            this.button17.Text = "ㅇ";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.White;
            this.button18.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button18.Location = new System.Drawing.Point(387, 328);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(69, 59);
            this.button18.TabIndex = 20;
            this.button18.Text = "ㅗ";
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.White;
            this.button19.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button19.Location = new System.Drawing.Point(107, 328);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(69, 59);
            this.button19.TabIndex = 19;
            this.button19.Text = "ㄴ";
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.White;
            this.button20.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button20.Location = new System.Drawing.Point(37, 328);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(69, 59);
            this.button20.TabIndex = 18;
            this.button20.Text = "ㅁ";
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button11.Location = new System.Drawing.Point(220, 268);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(69, 59);
            this.button11.TabIndex = 17;
            this.button11.Text = "ㄱ";
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button10.Location = new System.Drawing.Point(290, 268);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(69, 59);
            this.button10.TabIndex = 16;
            this.button10.Text = "ㅅ";
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button9.Location = new System.Drawing.Point(430, 268);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(69, 59);
            this.button9.TabIndex = 15;
            this.button9.Text = "ㅕ";
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button8.Location = new System.Drawing.Point(570, 268);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(69, 59);
            this.button8.TabIndex = 14;
            this.button8.Text = "ㅐ";
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button7.Location = new System.Drawing.Point(500, 268);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(69, 59);
            this.button7.TabIndex = 13;
            this.button7.Text = "ㅑ";
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button6.Location = new System.Drawing.Point(640, 268);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(69, 59);
            this.button6.TabIndex = 12;
            this.button6.Text = "ㅔ";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button5.Location = new System.Drawing.Point(150, 268);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(69, 59);
            this.button5.TabIndex = 11;
            this.button5.Text = "ㄷ";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button4.Location = new System.Drawing.Point(360, 268);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(69, 59);
            this.button4.TabIndex = 10;
            this.button4.Text = "ㅛ";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button3.Location = new System.Drawing.Point(80, 268);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(69, 59);
            this.button3.TabIndex = 9;
            this.button3.Text = "ㅈ";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(10, 268);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(69, 59);
            this.button2.TabIndex = 8;
            this.button2.Text = "ㅂ";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.White;
            this.btnLogin.Location = new System.Drawing.Point(198, 213);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(429, 33);
            this.btnLogin.TabIndex = 3;
            this.btnLogin.Text = "확인";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // txtUserName
            // 
            this.txtUserName.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold);
            this.txtUserName.Location = new System.Drawing.Point(288, 123);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(244, 29);
            this.txtUserName.TabIndex = 2;
            this.txtUserName.Text = "tester";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(191, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 37;
            this.label1.Text = "사용자 이름 : ";
            // 
            // pnlProcess
            // 
            this.pnlProcess.BackColor = System.Drawing.Color.White;
            this.pnlProcess.Controls.Add(this.btnCommTest);
            this.pnlProcess.Controls.Add(this.btnStart);
            this.pnlProcess.Controls.Add(this.rdoFlow1);
            this.pnlProcess.Controls.Add(this.btnTestProcess);
            this.pnlProcess.Controls.Add(this.rdoFlow2);
            this.pnlProcess.Controls.Add(this.btnStop);
            this.pnlProcess.Controls.Add(this.btnErrReset);
            this.pnlProcess.Controls.Add(this.btnErrManualDown);
            this.pnlProcess.Controls.Add(this.btnReScan);
            this.pnlProcess.Controls.Add(this.btnInitDevice);
            this.pnlProcess.Controls.Add(this.lblCurrTime);
            this.pnlProcess.Controls.Add(this.label16);
            this.pnlProcess.Controls.Add(this.panel2);
            this.pnlProcess.Controls.Add(this.panel3);
            this.pnlProcess.Controls.Add(this.panel4);
            this.pnlProcess.Controls.Add(this.label7);
            this.pnlProcess.Controls.Add(this.label6);
            this.pnlProcess.Controls.Add(this.label5);
            this.pnlProcess.Controls.Add(this.btnUserChg);
            this.pnlProcess.Controls.Add(this.lblCongrat);
            this.pnlProcess.Controls.Add(this.picLogo1);
            this.pnlProcess.Controls.Add(this.label3);
            this.pnlProcess.Controls.Add(this.txtCntPerMin);
            this.pnlProcess.Controls.Add(this.label2);
            this.pnlProcess.Controls.Add(this.btnCntChg);
            this.pnlProcess.Controls.Add(this.shapeContainer1);
            this.pnlProcess.Controls.Add(this.picMachineType);
            this.pnlProcess.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlProcess.Location = new System.Drawing.Point(0, 0);
            this.pnlProcess.Name = "pnlProcess";
            this.pnlProcess.Size = new System.Drawing.Size(798, 455);
            this.pnlProcess.TabIndex = 0;
            this.pnlProcess.Visible = false;
            // 
            // btnCommTest
            // 
            this.btnCommTest.Location = new System.Drawing.Point(756, 33);
            this.btnCommTest.Name = "btnCommTest";
            this.btnCommTest.Size = new System.Drawing.Size(24, 23);
            this.btnCommTest.TabIndex = 2;
            this.btnCommTest.Text = "..";
            this.btnCommTest.UseVisualStyleBackColor = true;
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.SteelBlue;
            this.btnStart.Font = new System.Drawing.Font("굴림", 11.25F);
            this.btnStart.ForeColor = System.Drawing.Color.White;
            this.btnStart.Location = new System.Drawing.Point(703, 155);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(70, 274);
            this.btnStart.TabIndex = 32;
            this.btnStart.Text = "시작";
            this.btnStart.UseVisualStyleBackColor = false;
            // 
            // rdoFlow1
            // 
            this.rdoFlow1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold);
            this.rdoFlow1.Location = new System.Drawing.Point(3, 149);
            this.rdoFlow1.Name = "rdoFlow1";
            this.rdoFlow1.Size = new System.Drawing.Size(106, 26);
            this.rdoFlow1.TabIndex = 22;
            this.rdoFlow1.Text = "정방향";
            this.rdoFlow1.CheckedChanged += new System.EventHandler(this.rdoFlow1_CheckedChanged);
            // 
            // btnTestProcess
            // 
            this.btnTestProcess.BackColor = System.Drawing.Color.DarkOrange;
            this.btnTestProcess.Font = new System.Drawing.Font("굴림", 11.25F);
            this.btnTestProcess.ForeColor = System.Drawing.Color.White;
            this.btnTestProcess.Location = new System.Drawing.Point(633, 155);
            this.btnTestProcess.Name = "btnTestProcess";
            this.btnTestProcess.Size = new System.Drawing.Size(69, 274);
            this.btnTestProcess.TabIndex = 31;
            this.btnTestProcess.Text = "시운전";
            this.btnTestProcess.UseVisualStyleBackColor = false;
            // 
            // rdoFlow2
            // 
            this.rdoFlow2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold);
            this.rdoFlow2.Location = new System.Drawing.Point(115, 149);
            this.rdoFlow2.Name = "rdoFlow2";
            this.rdoFlow2.Size = new System.Drawing.Size(106, 26);
            this.rdoFlow2.TabIndex = 23;
            this.rdoFlow2.Text = "역방향";
            this.rdoFlow2.CheckedChanged += new System.EventHandler(this.rdoFlow2_CheckedChanged);
            // 
            // btnStop
            // 
            this.btnStop.BackColor = System.Drawing.Color.Red;
            this.btnStop.Font = new System.Drawing.Font("굴림", 11.25F);
            this.btnStop.ForeColor = System.Drawing.Color.White;
            this.btnStop.Location = new System.Drawing.Point(562, 155);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(70, 274);
            this.btnStop.TabIndex = 30;
            this.btnStop.Text = "정지";
            this.btnStop.UseVisualStyleBackColor = false;
            // 
            // btnErrReset
            // 
            this.btnErrReset.BackColor = System.Drawing.Color.LimeGreen;
            this.btnErrReset.Font = new System.Drawing.Font("굴림", 11.25F);
            this.btnErrReset.ForeColor = System.Drawing.Color.White;
            this.btnErrReset.Location = new System.Drawing.Point(485, 155);
            this.btnErrReset.Name = "btnErrReset";
            this.btnErrReset.Size = new System.Drawing.Size(76, 274);
            this.btnErrReset.TabIndex = 29;
            this.btnErrReset.Text = "장애\r\n리셋";
            this.btnErrReset.UseVisualStyleBackColor = false;
            // 
            // btnErrManualDown
            // 
            this.btnErrManualDown.BackColor = System.Drawing.Color.DarkOrange;
            this.btnErrManualDown.ForeColor = System.Drawing.Color.White;
            this.btnErrManualDown.Location = new System.Drawing.Point(5, 430);
            this.btnErrManualDown.Name = "btnErrManualDown";
            this.btnErrManualDown.Size = new System.Drawing.Size(361, 25);
            this.btnErrManualDown.TabIndex = 28;
            this.btnErrManualDown.Text = "장애 처리 관리 메뉴얼 다운로드";
            this.btnErrManualDown.UseVisualStyleBackColor = false;
            // 
            // btnReScan
            // 
            this.btnReScan.BackColor = System.Drawing.Color.LimeGreen;
            this.btnReScan.Font = new System.Drawing.Font("굴림", 11.25F);
            this.btnReScan.ForeColor = System.Drawing.Color.White;
            this.btnReScan.Location = new System.Drawing.Point(369, 404);
            this.btnReScan.Name = "btnReScan";
            this.btnReScan.Size = new System.Drawing.Size(110, 25);
            this.btnReScan.TabIndex = 27;
            this.btnReScan.Text = "다시 스캔";
            this.btnReScan.UseVisualStyleBackColor = false;
            // 
            // btnInitDevice
            // 
            this.btnInitDevice.BackColor = System.Drawing.Color.DarkOrange;
            this.btnInitDevice.Font = new System.Drawing.Font("굴림", 11.25F);
            this.btnInitDevice.ForeColor = System.Drawing.Color.White;
            this.btnInitDevice.Location = new System.Drawing.Point(372, 194);
            this.btnInitDevice.Name = "btnInitDevice";
            this.btnInitDevice.Size = new System.Drawing.Size(107, 25);
            this.btnInitDevice.TabIndex = 26;
            this.btnInitDevice.Text = "기기 초기화";
            this.btnInitDevice.UseVisualStyleBackColor = false;
            // 
            // lblCurrTime
            // 
            this.lblCurrTime.Font = new System.Drawing.Font("굴림", 9.75F);
            this.lblCurrTime.Location = new System.Drawing.Point(628, 438);
            this.lblCurrTime.Name = "lblCurrTime";
            this.lblCurrTime.Size = new System.Drawing.Size(145, 17);
            this.lblCurrTime.TabIndex = 34;
            this.lblCurrTime.Text = "2020-08-02 15:30:19";
            this.lblCurrTime.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("굴림", 9.75F);
            this.label16.Location = new System.Drawing.Point(3, 178);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 13);
            this.label16.TabIndex = 35;
            this.label16.Text = "[기기 상태]";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.lblCntPerMin);
            this.panel2.Location = new System.Drawing.Point(5, 64);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(260, 71);
            this.panel2.TabIndex = 36;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("굴림", 12F);
            this.label9.Location = new System.Drawing.Point(190, 38);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 16);
            this.label9.TabIndex = 0;
            this.label9.Text = "ea/min";
            // 
            // lblCntPerMin
            // 
            this.lblCntPerMin.BackColor = System.Drawing.Color.Transparent;
            this.lblCntPerMin.Font = new System.Drawing.Font("굴림", 26.25F);
            this.lblCntPerMin.Location = new System.Drawing.Point(5, 22);
            this.lblCntPerMin.Name = "lblCntPerMin";
            this.lblCntPerMin.Size = new System.Drawing.Size(179, 35);
            this.lblCntPerMin.TabIndex = 1;
            this.lblCntPerMin.Text = " 0";
            this.lblCntPerMin.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.lblEaPerDay);
            this.panel3.Location = new System.Drawing.Point(271, 64);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(326, 71);
            this.panel3.TabIndex = 37;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("굴림", 12F);
            this.label10.Location = new System.Drawing.Point(259, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 16);
            this.label10.TabIndex = 0;
            this.label10.Text = "ea/day";
            // 
            // lblEaPerDay
            // 
            this.lblEaPerDay.BackColor = System.Drawing.Color.Transparent;
            this.lblEaPerDay.Font = new System.Drawing.Font("굴림", 26.25F);
            this.lblEaPerDay.Location = new System.Drawing.Point(3, 22);
            this.lblEaPerDay.Name = "lblEaPerDay";
            this.lblEaPerDay.Size = new System.Drawing.Size(251, 35);
            this.lblEaPerDay.TabIndex = 1;
            this.lblEaPerDay.Text = " 0";
            this.lblEaPerDay.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.lblErrCntPerDay);
            this.panel4.Location = new System.Drawing.Point(603, 64);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(170, 71);
            this.panel4.TabIndex = 38;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("굴림", 12F);
            this.label12.Location = new System.Drawing.Point(131, 37);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(24, 16);
            this.label12.TabIndex = 0;
            this.label12.Text = "회";
            // 
            // lblErrCntPerDay
            // 
            this.lblErrCntPerDay.BackColor = System.Drawing.Color.Transparent;
            this.lblErrCntPerDay.Font = new System.Drawing.Font("굴림", 26.25F);
            this.lblErrCntPerDay.Location = new System.Drawing.Point(13, 21);
            this.lblErrCntPerDay.Name = "lblErrCntPerDay";
            this.lblErrCntPerDay.Size = new System.Drawing.Size(112, 35);
            this.lblErrCntPerDay.TabIndex = 1;
            this.lblErrCntPerDay.Text = " 0";
            this.lblErrCntPerDay.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("굴림", 9.75F);
            this.label7.Location = new System.Drawing.Point(600, 45);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 13);
            this.label7.TabIndex = 39;
            this.label7.Text = "[오늘 장애 회수]";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("굴림", 9.75F);
            this.label6.Location = new System.Drawing.Point(268, 45);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 13);
            this.label6.TabIndex = 40;
            this.label6.Text = "[오늘 총 생산량]";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("굴림", 9.75F);
            this.label5.Location = new System.Drawing.Point(2, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 13);
            this.label5.TabIndex = 41;
            this.label5.Text = "[현재 속도]";
            // 
            // btnUserChg
            // 
            this.btnUserChg.BackColor = System.Drawing.Color.Black;
            this.btnUserChg.ForeColor = System.Drawing.Color.White;
            this.btnUserChg.Location = new System.Drawing.Point(665, 2);
            this.btnUserChg.Name = "btnUserChg";
            this.btnUserChg.Size = new System.Drawing.Size(115, 25);
            this.btnUserChg.TabIndex = 8;
            this.btnUserChg.Text = "사용자 변경";
            this.btnUserChg.UseVisualStyleBackColor = false;
            this.btnUserChg.Click += new System.EventHandler(this.btnUserChg_Click);
            // 
            // lblCongrat
            // 
            this.lblCongrat.Location = new System.Drawing.Point(498, 8);
            this.lblCongrat.Name = "lblCongrat";
            this.lblCongrat.Size = new System.Drawing.Size(163, 20);
            this.lblCongrat.TabIndex = 42;
            this.lblCongrat.Text = "?????님 환영합니다.";
            this.lblCongrat.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(128, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 20);
            this.label3.TabIndex = 44;
            this.label3.Text = "ea/min";
            // 
            // txtCntPerMin
            // 
            this.txtCntPerMin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCntPerMin.Location = new System.Drawing.Point(72, 6);
            this.txtCntPerMin.Name = "txtCntPerMin";
            this.txtCntPerMin.Size = new System.Drawing.Size(50, 14);
            this.txtCntPerMin.TabIndex = 2;
            this.txtCntPerMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F);
            this.label2.Location = new System.Drawing.Point(5, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 17);
            this.label2.TabIndex = 45;
            this.label2.Text = "생산속도 : ";
            // 
            // btnCntChg
            // 
            this.btnCntChg.BackColor = System.Drawing.Color.LimeGreen;
            this.btnCntChg.ForeColor = System.Drawing.Color.White;
            this.btnCntChg.Location = new System.Drawing.Point(182, 2);
            this.btnCntChg.Name = "btnCntChg";
            this.btnCntChg.Size = new System.Drawing.Size(100, 25);
            this.btnCntChg.TabIndex = 0;
            this.btnCntChg.Text = "설정변경";
            this.btnCntChg.UseVisualStyleBackColor = false;
            this.btnCntChg.Click += new System.EventHandler(this.btnCntChg_Click);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.ChkState2_7,
            this.ChkState2_6,
            this.ChkState2_5,
            this.ChkState2_4,
            this.ChkState2_3,
            this.ChkState2_2,
            this.ChkState2_1,
            this.ChkState1_5,
            this.ChkState1_4,
            this.ChkState1_6,
            this.ChkState1_7,
            this.ChkState1_2,
            this.ChkState1_8,
            this.ChkState1_3,
            this.ChkState1_1});
            this.shapeContainer1.Size = new System.Drawing.Size(798, 455);
            this.shapeContainer1.TabIndex = 46;
            this.shapeContainer1.TabStop = false;
            // 
            // ChkState1_1
            // 
            this.ChkState1_1.BackColor = System.Drawing.Color.Transparent;
            this.ChkState1_1.BorderColor = System.Drawing.Color.Red;
            this.ChkState1_1.BorderWidth = 3;
            this.ChkState1_1.FillColor = System.Drawing.Color.Transparent;
            this.ChkState1_1.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState1_1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState1_1.Location = new System.Drawing.Point(126, 179);
            this.ChkState1_1.Name = "ChkState1_1";
            this.ChkState1_1.Size = new System.Drawing.Size(30, 30);
            this.ChkState1_1.Visible = false;
            // 
            // tmrCurrTime
            // 
            this.tmrCurrTime.Interval = 1000;
            this.tmrCurrTime.Tick += new System.EventHandler(this.tmrCurrTime_Tick);
            // 
            // serialP1
            // 
            this.serialP1.BaudRate = 115200;
            this.serialP1.Parity = System.IO.Ports.Parity.Odd;
            // 
            // ChkState1_3
            // 
            this.ChkState1_3.BackColor = System.Drawing.Color.Transparent;
            this.ChkState1_3.BorderColor = System.Drawing.Color.Red;
            this.ChkState1_3.BorderWidth = 3;
            this.ChkState1_3.FillColor = System.Drawing.Color.Transparent;
            this.ChkState1_3.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState1_3.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState1_3.Location = new System.Drawing.Point(314, 201);
            this.ChkState1_3.Name = "ChkState1_3";
            this.ChkState1_3.Size = new System.Drawing.Size(30, 30);
            this.ChkState1_3.Visible = false;
            // 
            // ChkState1_8
            // 
            this.ChkState1_8.BackColor = System.Drawing.Color.Transparent;
            this.ChkState1_8.BorderColor = System.Drawing.Color.Red;
            this.ChkState1_8.BorderWidth = 3;
            this.ChkState1_8.FillColor = System.Drawing.Color.Transparent;
            this.ChkState1_8.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState1_8.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState1_8.Location = new System.Drawing.Point(314, 400);
            this.ChkState1_8.Name = "ovalShape2";
            this.ChkState1_8.Size = new System.Drawing.Size(30, 30);
            this.ChkState1_8.Visible = false;
            // 
            // ChkState1_2
            // 
            this.ChkState1_2.BackColor = System.Drawing.Color.Transparent;
            this.ChkState1_2.BorderColor = System.Drawing.Color.Red;
            this.ChkState1_2.BorderWidth = 3;
            this.ChkState1_2.FillColor = System.Drawing.Color.Transparent;
            this.ChkState1_2.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState1_2.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState1_2.Location = new System.Drawing.Point(187, 217);
            this.ChkState1_2.Name = "ChkState1_2";
            this.ChkState1_2.Size = new System.Drawing.Size(30, 30);
            this.ChkState1_2.Visible = false;
            // 
            // ChkState1_7
            // 
            this.ChkState1_7.BackColor = System.Drawing.Color.Transparent;
            this.ChkState1_7.BorderColor = System.Drawing.Color.Red;
            this.ChkState1_7.BorderWidth = 3;
            this.ChkState1_7.FillColor = System.Drawing.Color.Transparent;
            this.ChkState1_7.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState1_7.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState1_7.Location = new System.Drawing.Point(150, 360);
            this.ChkState1_7.Name = "ChkState1_7";
            this.ChkState1_7.Size = new System.Drawing.Size(30, 30);
            this.ChkState1_7.Visible = false;
            // 
            // ChkState1_6
            // 
            this.ChkState1_6.BackColor = System.Drawing.Color.Transparent;
            this.ChkState1_6.BorderColor = System.Drawing.Color.Red;
            this.ChkState1_6.BorderWidth = 3;
            this.ChkState1_6.FillColor = System.Drawing.Color.Transparent;
            this.ChkState1_6.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState1_6.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState1_6.Location = new System.Drawing.Point(45, 366);
            this.ChkState1_6.Name = "ChkState1_6";
            this.ChkState1_6.Size = new System.Drawing.Size(30, 30);
            this.ChkState1_6.Visible = false;
            // 
            // ChkState1_4
            // 
            this.ChkState1_4.BackColor = System.Drawing.Color.Transparent;
            this.ChkState1_4.BorderColor = System.Drawing.Color.Red;
            this.ChkState1_4.BorderWidth = 3;
            this.ChkState1_4.FillColor = System.Drawing.Color.Transparent;
            this.ChkState1_4.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState1_4.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState1_4.Location = new System.Drawing.Point(36, 292);
            this.ChkState1_4.Name = "ChkState1_4";
            this.ChkState1_4.Size = new System.Drawing.Size(30, 30);
            this.ChkState1_4.Visible = false;
            // 
            // ChkState1_5
            // 
            this.ChkState1_5.BackColor = System.Drawing.Color.Transparent;
            this.ChkState1_5.BorderColor = System.Drawing.Color.Red;
            this.ChkState1_5.BorderWidth = 3;
            this.ChkState1_5.FillColor = System.Drawing.Color.Transparent;
            this.ChkState1_5.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState1_5.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState1_5.Location = new System.Drawing.Point(5, 372);
            this.ChkState1_5.Name = "ChkState1_5";
            this.ChkState1_5.Size = new System.Drawing.Size(30, 30);
            this.ChkState1_5.Visible = false;
            // 
            // picLogo1
            // 
            this.picLogo1.Location = new System.Drawing.Point(299, 2);
            this.picLogo1.Name = "picLogo1";
            this.picLogo1.Size = new System.Drawing.Size(151, 27);
            this.picLogo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogo1.TabIndex = 43;
            this.picLogo1.TabStop = false;
            // 
            // picMachineType
            // 
            this.picMachineType.BackColor = System.Drawing.Color.WhiteSmoke;
            this.picMachineType.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources._2공정_;
            this.picMachineType.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picMachineType.Location = new System.Drawing.Point(6, 194);
            this.picMachineType.Name = "picMachineType";
            this.picMachineType.Size = new System.Drawing.Size(361, 235);
            this.picMachineType.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picMachineType.TabIndex = 33;
            this.picMachineType.TabStop = false;
            // 
            // picLogo
            // 
            this.picLogo.Location = new System.Drawing.Point(288, 44);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(244, 51);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogo.TabIndex = 38;
            this.picLogo.TabStop = false;
            // 
            // ChkState2_1
            // 
            this.ChkState2_1.BackColor = System.Drawing.Color.Transparent;
            this.ChkState2_1.BorderColor = System.Drawing.Color.DodgerBlue;
            this.ChkState2_1.BorderWidth = 3;
            this.ChkState2_1.FillColor = System.Drawing.Color.Transparent;
            this.ChkState2_1.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState2_1.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState2_1.Location = new System.Drawing.Point(246, 204);
            this.ChkState2_1.Name = "ChkState2_1";
            this.ChkState2_1.Size = new System.Drawing.Size(30, 30);
            this.ChkState2_1.Visible = false;
            // 
            // ChkState2_2
            // 
            this.ChkState2_2.BackColor = System.Drawing.Color.Transparent;
            this.ChkState2_2.BorderColor = System.Drawing.Color.LimeGreen;
            this.ChkState2_2.BorderWidth = 3;
            this.ChkState2_2.FillColor = System.Drawing.Color.Transparent;
            this.ChkState2_2.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState2_2.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState2_2.Location = new System.Drawing.Point(107, 202);
            this.ChkState2_2.Name = "ChkState2_2";
            this.ChkState2_2.Size = new System.Drawing.Size(30, 30);
            this.ChkState2_2.Visible = false;
            // 
            // ChkState2_3
            // 
            this.ChkState2_3.BackColor = System.Drawing.Color.Transparent;
            this.ChkState2_3.BorderColor = System.Drawing.Color.LimeGreen;
            this.ChkState2_3.BorderWidth = 3;
            this.ChkState2_3.FillColor = System.Drawing.Color.Transparent;
            this.ChkState2_3.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState2_3.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState2_3.Location = new System.Drawing.Point(44, 216);
            this.ChkState2_3.Name = "ChkState2_3";
            this.ChkState2_3.Size = new System.Drawing.Size(30, 30);
            this.ChkState2_3.Visible = false;
            // 
            // ChkState2_4
            // 
            this.ChkState2_4.BackColor = System.Drawing.Color.Transparent;
            this.ChkState2_4.BorderColor = System.Drawing.Color.LimeGreen;
            this.ChkState2_4.BorderWidth = 3;
            this.ChkState2_4.FillColor = System.Drawing.Color.Transparent;
            this.ChkState2_4.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState2_4.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState2_4.Location = new System.Drawing.Point(244, 282);
            this.ChkState2_4.Name = "ChkState2_4";
            this.ChkState2_4.Size = new System.Drawing.Size(30, 30);
            this.ChkState2_4.Visible = false;
            // 
            // ChkState2_5
            // 
            this.ChkState2_5.BackColor = System.Drawing.Color.Transparent;
            this.ChkState2_5.BorderColor = System.Drawing.Color.LimeGreen;
            this.ChkState2_5.BorderWidth = 3;
            this.ChkState2_5.FillColor = System.Drawing.Color.Transparent;
            this.ChkState2_5.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState2_5.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState2_5.Location = new System.Drawing.Point(110, 284);
            this.ChkState2_5.Name = "ChkState2_5";
            this.ChkState2_5.Size = new System.Drawing.Size(30, 30);
            this.ChkState2_5.Visible = false;
            // 
            // ChkState2_6
            // 
            this.ChkState2_6.BackColor = System.Drawing.Color.Transparent;
            this.ChkState2_6.BorderColor = System.Drawing.Color.LimeGreen;
            this.ChkState2_6.BorderWidth = 3;
            this.ChkState2_6.FillColor = System.Drawing.Color.Transparent;
            this.ChkState2_6.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState2_6.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState2_6.Location = new System.Drawing.Point(305, 331);
            this.ChkState2_6.Name = "ChkState2_6";
            this.ChkState2_6.Size = new System.Drawing.Size(30, 30);
            this.ChkState2_6.Visible = false;
            // 
            // ChkState2_7
            // 
            this.ChkState2_7.BackColor = System.Drawing.Color.Transparent;
            this.ChkState2_7.BorderColor = System.Drawing.Color.LimeGreen;
            this.ChkState2_7.BorderWidth = 3;
            this.ChkState2_7.FillColor = System.Drawing.Color.Transparent;
            this.ChkState2_7.FillGradientColor = System.Drawing.Color.Transparent;
            this.ChkState2_7.FillStyle = Microsoft.VisualBasic.PowerPacks.FillStyle.Solid;
            this.ChkState2_7.Location = new System.Drawing.Point(36, 355);
            this.ChkState2_7.Name = "ChkState2_7";
            this.ChkState2_7.Size = new System.Drawing.Size(30, 30);
            this.ChkState2_7.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(798, 455);
            this.Controls.Add(this.pnlProcess);
            this.Controls.Add(this.pnlLogin);
            this.MaximizeBox = false;
            this.Menu = this.mainMenu1;
            this.MinimizeBox = false;
            this.Name = "Form2";
            this.Text = "Control Device (Client)";
            this.pnlLogin.ResumeLayout(false);
            this.pnlLogin.PerformLayout();
            this.pnlProcess.ResumeLayout(false);
            this.pnlProcess.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMachineType)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlLogin;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.TextBox txtUserName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.Panel pnlProcess;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.RadioButton rdoFlow1;
        private System.Windows.Forms.Button btnTestProcess;
        private System.Windows.Forms.RadioButton rdoFlow2;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnErrReset;
        private System.Windows.Forms.Button btnErrManualDown;
        private System.Windows.Forms.Button btnReScan;
        private System.Windows.Forms.Button btnInitDevice;
        private System.Windows.Forms.PictureBox picMachineType;
        private System.Windows.Forms.Label lblCurrTime;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblCntPerMin;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblEaPerDay;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblErrCntPerDay;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnUserChg;
        private System.Windows.Forms.Label lblCongrat;
        private System.Windows.Forms.PictureBox picLogo1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCntPerMin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCntChg;
        private System.Windows.Forms.Timer tmrCurrTime;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState1_1;
        private System.Windows.Forms.Button btnCommTest;
        private System.IO.Ports.SerialPort serialP1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState1_5;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState1_4;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState1_6;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState1_7;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState1_2;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState1_8;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState1_3;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState2_1;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState2_7;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState2_6;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState2_5;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState2_4;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState2_3;
        private Microsoft.VisualBasic.PowerPacks.OvalShape ChkState2_2;
    }
}