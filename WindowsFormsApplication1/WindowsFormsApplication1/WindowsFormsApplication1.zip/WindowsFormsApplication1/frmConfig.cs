﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SmartSerialPort_NewEX
{
    public partial class frmConfigP1 : Form
    {
        public frmConfigP1()
        {
            InitializeComponent();
        }
    }
}